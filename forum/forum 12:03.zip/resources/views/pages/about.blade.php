@extends('layouts.forum')

@section('content')
    <h1>About</h1>
    <p>This website was created for a University assignment using Laravele.</p><br>

<p>The scenario was an online forum where authenticated users can carry out CRUD operations.
    Discussion topics can be created which other users can view and respond. </p>

@endsection

