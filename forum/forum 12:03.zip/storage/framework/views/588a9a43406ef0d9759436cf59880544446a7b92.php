<?php $__env->startSection('content'); ?>
    <br>
    <h1>Topics</h1>

    <?php echo Form::open(['action' => 'TopicController@search', 'method' => 'GET']); ?>

        <div class="form-group">
            <?php echo e(Form::label('search', 'Search by Author:')); ?>

            <?php echo e(Form::text('search', '')); ?>

            <?php echo e(Form::submit('Search', ['class' => 'btn btn-primary'])); ?>

            <a href="/assignment-1-laravel-Alexjs95/forum/public/topics">Reset Search</a>
        </div>
    <?php echo Form::close(); ?>


    <?php if(count($topics) > 0): ?> 
        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card card-body bg-light">
                <h4><a href="/assignment-1-laravel-Alexjs95/forum/public/topics/<?php echo e($topic->id); ?>"><?php echo e($topic->title); ?></a></h4>
                <small>created on <?php echo e($topic->created_at); ?> by <?php echo e($topic->user['name']); ?></small>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($topics->links()); ?>

    <?php else: ?>
        <p>No topics found<p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.forum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>