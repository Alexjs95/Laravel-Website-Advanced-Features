<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1>Games Discussion Forum</h1>
        <p></p>
        <p>
            <a class="btn btn-primary btn-lg" href="/assignment-1-laravel-Alexjs95/forum/public/login" role="button"> Login </a>
            <a class="btn btn-success btn-lg" href="/assignment-1-laravel-Alexjs95/forum/public/register" role="button"> Register </a>
        </p>        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.forum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>