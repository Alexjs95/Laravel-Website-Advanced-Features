<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"> <!-- uses existing css file containing bootstap-->
        <title><?php echo e(config('app.name', 'ASForum')); ?></title>
    </head>
    <body>
        <?php echo $__env->make('include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="container">
            <?php echo $__env->make('include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>           <!--laravel blade snippets exention -->
        </div>

        <!-- Scripts -->
        <script src="<?php echo e(URL::asset('../vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
        <script>
            CKEDITOR.replace( 'article-ckeditor' );
        </script>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
        <script src="//code.jquery.com/jquery-1.10.2.js"></script>
        <script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
        <script>
            $(function() {
                $( "#datepicker1" ).datepicker({
                    dateFormat: 'yy/mm/dd'
                });
            });
        </script>
        <script>
        $(function() {
            $( "#datepicker2" ).datepicker({
                dateFormat: 'yy/mm/dd'
            });
        });
        </script>


    </body>
</html>
