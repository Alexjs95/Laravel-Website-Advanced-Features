<?php $__env->startSection('content'); ?>
    <h1>About</h1>
    <p>This website was created for a University assignment using Laravele.</p><br>

<p>The scenario was an online forum where authenticated users can carry out CRUD operations.
    Discussion topics can be created which other users can view and respond. </p>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.forum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>