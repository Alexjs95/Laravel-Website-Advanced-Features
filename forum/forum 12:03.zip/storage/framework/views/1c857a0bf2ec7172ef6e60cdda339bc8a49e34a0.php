<?php $__env->startSection('content'); ?>
    <br>
    <h1>Adding new post</h1>
    <?php echo Form::open(['action' => ['TopicPostController@store', $topic->id], 'method' => 'POST']); ?>

        <div class='form-group'>
            <?php echo e(Form::label('body', 'Text for topic: ')); ?>

            <?php echo e(Form::textarea('body', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Enter some text...'])); ?>

        </div> 
        <?php echo e(Form::hidden('id', $topic->id)); ?>

        <?php echo e(Form::submit('Add message to topic', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.forum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>