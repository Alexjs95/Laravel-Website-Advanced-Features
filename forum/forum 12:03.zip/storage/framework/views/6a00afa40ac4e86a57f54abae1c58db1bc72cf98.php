<?php $__env->startSection('content'); ?>
    <br>
    <a href="/assignment-1-laravel-Alexjs95/forum/public/topics" class="btn btn-secondary">Back to topics</a>

    <?php if(!Auth::guest()): ?>        <!-- if the user is not a guest then show edit/delete buttons -->
        <?php if(Auth::user()->id == $topic->user_id): ?>    <!-- only enable the edit/delete buttons if the current user is the topic owner -->
            <a href="/assignment-1-laravel-Alexjs95/forum/public/topics/<?php echo e($topic->id); ?>/edit" class="btn btn-secondary"> Edit topic</a>
            <br><br>
            <?php echo Form::open(['action' => ['TopicController@destroy', $topic->id], 'method' => 'POST']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete topic', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
    <br><br>
    <h1><?php echo e($topic->title); ?></h1>
    
        <h4><?php echo $topic->body; ?></h4>      <!-- double !! to parse html --> 
  
    <br>
    <?php if(!Auth::guest()): ?>        <!-- if the user is not a guest then show add new message button -->
        <a href="/assignment-1-laravel-Alexjs95/forum/public/topicposts/create/<?php echo e($topic->id); ?>" class="btn btn-secondary">Add new post to topic</a>
        <br><br>
    <?php endif; ?>

    <?php if(count($posts) > 0): ?> 
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card card-body bg-light">
                <h4><?php echo $post->body; ?></h4>
                <small>added on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->links()); ?>

    <?php else: ?>
        <p>No posts found<p>
    <?php endif; ?>


    <hr><small>Topic created on <?php echo e($topic->created_at); ?> by <?php echo e($topic->user->name); ?></small>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.forum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>